const makeRatingFile = require("./raiting-file");
const config = require("./config");
const { createRating, updataRating } = require("./calculations");

module.exports = {
    makeRatingFile,
    config,
    createRating,
    updataRating,
}