const PATH_TORATING_FILE = "./dataset/raiting.json";

const WEIGHT = {
    gameplay: 2,
    design: 1,
    idea: 3,
}

module.exports= {PATH_TORATING_FILE, WEIGHT};