const { getData, getRandomGame } = require("./api-utils");
const endpoints = require("./confing");

module.exports = {
    getData,
    getRandomGame,
    endpoints,
}